# Chatbot Frontend
A simple chatbot frontend for plugging in my bots.

To add a user message to the chat window
run javascript function -

    showUserMessage("Message",getCurrentTimestamp());

To add a bot message to the chat window
run javascript function -

    showBotMessage("Message",getCurrentTimestamp());

## Screenshot
![enter image description here](./static/img/demo.png)

PR's are welcome :)
