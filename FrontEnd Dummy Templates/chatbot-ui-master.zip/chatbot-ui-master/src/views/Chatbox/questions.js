export const questions = [
    {
        title: "Can I redeem my FD before the original term?"
    },
    {
        title: "How do I pay my Credit card bill?"
    },
    {
        title: "How can I get my Account Statement?"
    },
    {
        title: "What is the tenure of Fixed Deposit?"
    }
]